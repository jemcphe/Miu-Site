/*JSON File
 * VFW - Week 4
 * James McPherson
 * 1203
 * 03/18/2012
 */

var json = {
		"player1": {
				"position": ["Position: ", "QB"],
				"pname"	: ["Player Name: ", "Tony Romo"],
				"team"		: ["Team Name: ", "Dallas Cowboys"],
				"bye"			: ["Bye Week: ", "12/12/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "8"],
				"notes"		: ["Notes: ", "Scrambler"]
		},
		"player2": {
				"position": ["Position: ", "RB"],
				"pname"	: ["Player Name: ", "Adrian Peterson"],
				"team"		: ["Team Name: ", "Minnesota Vikings"],
				"bye"			: ["Bye Week: ", "11/12/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "10"],
				"notes"		: ["Notes: ", "Fast"]
		},
		"player3": {
				"position": ["Position: ", "WR"],
				"pname"	: ["Player Name: ", "Larry Fitzgerald"],
				"team"		: ["Team Name: ", "Arizona Cardinals"],
				"bye"			: ["Bye Week: ", "10/10/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "9"],
				"notes"		: ["Notes: ", "Catches Everything"]
		},
		"player4": {
				"position": ["Position: ", "TE"],
				"pname"	: ["Player Name: ", "Rob Gronkowski"],
				"team"		: ["Team Name: ", "New England Patriots"],
				"bye"			: ["Bye Week: ", "11/12/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "9"],
				"notes"		: ["Notes: ", "Bull"]
		},
		"player5": {
				"position": ["Position: ", "K"],
				"pname"	: ["Player Name: ", "Garret Hartley"],
				"team"		: ["Team Name: ", "New Orleans Saints"],
				"bye"			: ["Bye Week: ", "10/10/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "10"],
				"notes"		: ["Notes: ", "Accurate Kicker"]
		},
		"player6": {
				"position": ["Position: ", "DEF"],
				"pname"	: ["Player Name: ", "SanFrancisco 49ers"],
				"team"		: ["Team Name: ", "SanFrancisco 49ers"],
				"bye"			: ["Bye Week: ", "12/12/2012"],
				"starter"	: ["Starter: ", "Yes"],
				"skill"			: ["Skill: ", "9"],
				"notes"		: ["Notes: ", "Great Pass Rush, Shut Down Defense"]
		}
}
